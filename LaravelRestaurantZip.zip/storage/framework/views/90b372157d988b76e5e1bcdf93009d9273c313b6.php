
<?php $__env->startSection('title', 'Restaurants'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Danh sách cơ sở, chi nhánh</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Report</a>
    </div>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div style="padding-bottom: 10px">
        <a href="<?php echo e(url("/backend/restaurant/create")); ?>" class="btn btn-primary">Tạo mới</a>
        <a href="<?php echo e(url("/backend/restaurant/index")); ?>" class="btn btn-success">Refresh</a>
    </div>

    <form name="searchfilter" method="get" action="<?php echo e(htmlspecialchars($_SERVER["REQUEST_URI"])); ?>" style="border: 1px solid grey; border-radius: 5px; padding: 10px;">
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="keyword">Tìm kiếm</label>
                    <input type="text" name="keyword" id="keyword" class="form-control" placeholder="Search for..." value="<?php echo e($search_keyword); ?>">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="whereArea">Theo khu vực...</label>
                    <select name="whereArea" id="whereArea" class="custom-select">
                        <option value="">Choose...</option>
                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($area); ?>" <?php echo e($whereArea == $area ? "selected" : ""); ?>><?php echo e($area); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="col-md-4">
                <div class="form-group">
                    <label for="whereOpenStatus">Trạng thái đóng/mở...</label>
                    <select name="whereOpenStatus" id="whereOpenStatus" class="custom-select">
                        <option value="">Choose...</option>
                        <option value="0" <?php echo e($whereOpenStatus == "0" ? "selected" : ""); ?>>Sắp khai trương</option>
                        <option value="1" <?php echo e($whereOpenStatus == "1" ? "selected" : ""); ?>>Đang hoạt động</option>
                        <option value="2" <?php echo e($whereOpenStatus == "2" ? "selected" : ""); ?>>Tạm ngưng hoạt động</option>
                        <option value="3" <?php echo e($whereOpenStatus == "3" ? "selected" : ""); ?>>Đã đóng vĩnh viễn</option>
                    </select>
                </div>
            </div>

            <div class="col-md-3">
                <div class="form-group">
                    <label for="whereSystemStatus">Trạng thái khóa...</label>
                    <select name="whereSystemStatus" id="whereSystemStatus" class="custom-select">
                        <option value="">Choose...</option>
                        <option value="1" <?php echo e($whereSystemStatus == "1" ? "selected" : ""); ?>>Mở khóa</option>
                        <option value="0" <?php echo e($whereSystemStatus == "0" ? "selected" : ""); ?>>Đang khóa</option>
                    </select>
                </div>
            </div>

            <div class="col-md-1">
                <div class="form-group">
                    <label for="">Filter</label>
                    <div><button class="btn" style="background: #5a5c69; color: white;"><i class="fas fa-search"></i></button></div>
                </div>
            </div>
        </div>
    </form>

    <table class="table table-bordered table-striped table-sm">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th></th>
                <th>Name</th>
                <th>Address</th>
                <th>Area</th>
                <th>Phone</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            <?php if(isset($restaurants) && !empty($restaurants)): ?>
                <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($restaurant->id); ?></th>
                    <td style="text-align: center">
                        <?php if($restaurant->Restaurant_SystemStatus == 1): ?>
                            <span style="color:	#0000cd"><i class="fas fa-lock-open"></i></span>
                        <?php endif; ?>
                        <?php if($restaurant->Restaurant_SystemStatus == 0): ?>
                            <span style="color:	#cd0000"><i class="fas fa-lock"></i></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($restaurant->Restaurant_Name); ?>

                        <div>
                            <?php if($restaurant->Restaurant_OpenStatus == 0): ?>
                                <span style="color:white; background: #ffc125">&nbspSắp khai trương&nbsp</span>
                            <?php endif; ?>
                            <?php if($restaurant->Restaurant_OpenStatus == 1): ?>
                                <span style="color:white; background: #008b00">&nbspĐang hoạt động&nbsp</span>
                            <?php endif; ?>
                            <?php if($restaurant->Restaurant_OpenStatus == 2): ?>
                                <span style="color:white; background: #8b2323">&nbspTạm ngưng hoạt động&nbsp</span>
                            <?php endif; ?>
                            <?php if($restaurant->Restaurant_OpenStatus == 3): ?>
                                <span style="color:white; background: #999999">&nbspĐã đóng vĩnh viễn&nbsp</span>
                            <?php endif; ?>
                        </div>
                    </td>
                    <td><?php echo e($restaurant->Restaurant_Address); ?></td>
                    <td><?php echo e($restaurant->Restaurant_Area); ?></td>
                    <td><?php echo e($restaurant->Restaurant_Phone); ?></td>
                    <td>
                        <a href="<?php echo e(url("/backend/restaurant/info/$restaurant->id")); ?>" class="btn btn-info" data-toggle="tooltip" title="Info"><i class="fas fa-info-circle"></i></a>
                        <a href="<?php echo e(url("/backend/restaurant/edit/$restaurant->id")); ?>" class="btn btn-warning" data-toggle="tooltip" title="Edit"><i class="fas fa-edit"></i></a>
                        <a href="<?php echo e(url("/backend/restaurant/delete/$restaurant->id")); ?>" class="btn btn-danger" data-toggle="tooltip" title="Delete"><i class="fas fa-minus-circle"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                Chưa có bản ghi nào trong bảng này
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($restaurants->links("pagination::bootstrap-4")); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('appendjs'); ?>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/backend/restaurants/index.blade.php ENDPATH**/ ?>