
<?php $__env->startSection('title', "Track"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container" id="track-container">

        <form id="track-form" method="post" action="<?php echo e(url('track')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-11">
                    <div class="form-group">
                        <label for="keyword">Tracking code:</label>
                        <input type="text" name="keyword" id="keyword" class="form-control" placeholder="Type here..." value="<?php echo e($track_keyword); ?>">
                    </div>
                </div>
                <div class="col-sm-1">
                    <div class="form-group">
                        <label for="">Track</label>
                        <div><button class="btn" style="background-color: #5a5c69; color: white;"><i class="fas fa-search"></i></button></div>
                    </div>
                </div>
            </div>
        </form>

        <?php if(isset($order) && $order!=null): ?>
            <table id="track-table-info" class="table table-bordered">
                <tr>
                    <th>Tracking Code</th>
                    <th><?php echo e($order->Order_TrackingCode); ?></th>
                </tr>
                <tr>
                    <th>Status</th>
                    <td>
                        <?php echo e($order->Order_Status == 0 ? $orderstatus[0] : ""); ?>

                        <?php echo e($order->Order_Status == 1 ? $orderstatus[1] : ""); ?>

                        <?php echo e($order->Order_Status == 2 ? $orderstatus[2] : ""); ?>

                        <?php echo e($order->Order_Status == 3 ? $orderstatus[3] : ""); ?>

                        <?php echo e($order->Order_Status == 4 ? $orderstatus[4] : ""); ?>

                        <?php echo e($order->Order_Status == 5 ? $orderstatus[5] : ""); ?>

                    </td>
                </tr>
                <tr>
                    <th>Restaurant</th>
                    <td><?php echo e($order->Order_RestaurantName); ?></td>
                </tr>
                <tr>
                    <th>Total Item</th>
                    <td><?php echo e($order->Order_TotalItem); ?></td>
                </tr>
                <tr>
                    <th>Total Quantity</th>
                    <td><?php echo e($order->Order_TotalQuantity); ?></td>
                </tr>
                <tr>
                    <th>Total Price</th>
                    <td><?php echo e($order->Order_TotalPrice); ?></td>
                </tr>
                <tr>
                    <th>Order Note</th>
                    <td><?php echo e($order->Order_Note); ?></td>
                </tr>
                <tr>
                    <th>Time Request</th>
                    <td><?php echo e($order->Order_Time_Request); ?></td>
                </tr>
                <tr>
                    <th>Time Accept</th>
                    <td><?php echo e($order->Order_Time_Accept); ?></td>
                </tr>
                <tr>
                    <th>Time Complete</th>
                    <td><?php echo e($order->Order_Time_Complete); ?></td>
                </tr>
                <tr>
                    <th>Time Receive</th>
                    <td><?php echo e($order->Order_Time_Receive); ?></td>
                </tr>
                <tr>
                    <th>Time Cancel</th>
                    <td><?php echo e($order->Order_Time_Cancel); ?></td>
                </tr>
                <tr>
                    <th>Cancel By</th>
                    <td><?php echo e($order->Order_CancelBy); ?></td>
                </tr>
                <tr>
                    <th>Cancel Reason</th>
                    <td><?php echo e($order->Order_CancelReason); ?></td>
                </tr>
                <tr>
                    <th>Time Return</th>
                    <td><?php echo e($order->Order_Time_Return); ?></td>
                </tr>
                <tr>
                    <th>Return Reason</th>
                    <td><?php echo e($order->Order_ReturnReason); ?></td>
                </tr>
            </table>
        <?php endif; ?>

        <?php if(isset($orderdetails) && $orderdetails!=null): ?>
            <h3 style="border-bottom: 1px solid darkgreen; padding-bottom: 12px; color: darkgreen;">Order details</h3>
            <table class="table table-bordered table-sm">
                <tbody style="color: darkolivegreen">
                    <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <label style="font-size: large">
                                <i class="far fa-sticky-note"></i>
                                <b><?php echo e($orderdetail->OrderDetail_ProductName); ?> (x<?php echo e($orderdetail->OrderDetail_Quantity); ?>)</b>
                            </label><br>
                            <label>- Price: <b><?php echo e($orderdetail->OrderDetail_ProductPrice); ?></b></label><br>
                            <label>- Total Price: <b><?php echo e($orderdetail->OrderDetail_TotalPrice); ?></b></label><br>
                            <label>- Detail Note: <b><?php echo e($orderdetail->OrderDetail_Note); ?></b></label>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/track.blade.php ENDPATH**/ ?>