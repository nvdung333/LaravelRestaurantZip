
<?php $__env->startSection('title', 'Homepage'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row no-gutters">
        <div id="home-content">
            <div id="home-content-img-center">
                <img class="img-fluid" src="<?php echo e(asset("/storage/images_setting/banner-center.jpg")); ?>" alt="center-img">
            </div>
            <div class="row no-gutters" id="home-content-img-side">
                <div class="col-6" id="home-content-img-left">
                    <img class="img-fluid" src="<?php echo e(asset("/storage/images_setting/banner-left.jpg")); ?>" alt="left-img">
                </div>
                <div class="col-6" id="home-content-img-right">
                    <img class="img-fluid" src="<?php echo e(asset("/storage/images_setting/banner-right.jpg")); ?>" alt="right-img">
                </div>
            </div>
            <div id="home-content-link">
                <a href="<?php echo e(url('search')); ?>" class="btn" role="button">
                    <i class="fab fa-elementor"></i>
                    <span id="home-content-link-title">MENU</span>
                </a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/homepage.blade.php ENDPATH**/ ?>