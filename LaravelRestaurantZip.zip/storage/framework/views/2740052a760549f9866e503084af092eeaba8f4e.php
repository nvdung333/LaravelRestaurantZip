
<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Thêm thể loại hàng hóa</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Report</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" action="<?php echo e(url("/backend/category/store")); ?>">
        
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="Category_Name">Name:</label>
            <input type="text" name="Category_Name" id="Category_Name" class="form-control" value="<?php echo e(old('Category_Name', "")); ?>">
        </div>

        <div class="form-group">
            <label for="Category_Img">Image:</label>
            <input type="file" name="Category_Img" class="form-control" id="Category_Img">
        </div>

        <div class="form-group">
            <label for="Category_Description">Description:</label>
            <textarea name="Category_Description" class="form-control" rows="5" id="Category_Description"><?php echo e(old('Category_Description', "")); ?></textarea>
        </div>

        <div class="form-group">
            <label for="Category_Parent_ID">Parent Category:</label>
            <select class="custom-select" name="Category_Parent_ID" id="Category_Parent_ID">
                <option value="">Choose...</option>
                <?php $__currentLoopData = $parentcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($parentcategory->id); ?>" <?php echo e(old('Category_Parent_ID') == "$parentcategory->id" ? "selected" : ""); ?>><?php echo e($parentcategory->Category_Name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Create</button>
        <a href="<?php echo e(url("/backend/category/index")); ?>" class="btn btn-secondary">Trở về</a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/backend/categories/create.blade.php ENDPATH**/ ?>