
<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Xóa danh mục hàng hóa</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Report</a>
    </div>

    <form method="post" enctype="multipart/form-data" action="<?php echo e(url("/backend/category/destroy/$category->id")); ?>">
        
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="id">ID:</label>
                    <input type="text" name="id" id="id" class="form-control" value="<?php echo e($category->id); ?>" readonly>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Category_Name">Name:</label>
                    <input type="text" name="Category_Name" id="Category_Name" class="form-control" value="<?php echo e($category->Category_Name); ?>" readonly>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">                
                <div class="form-group">
                    <?php $category->Category_Img = str_replace("public/", "", $category->Category_Img); ?>
                    <img alt=".img" src="<?php echo e(asset("storage/$category->Category_Img")); ?>" style="width: 250px; height: auto" />
                </div>
            </div>
        </div>
        
        <button type="submit" class="btn btn-danger">Destroy</button>
        <a href="<?php echo e(url("/backend/category/info/$category->id")); ?>" class="btn btn-info">Info</a>
        <a href="<?php echo e(url("/backend/category/index")); ?>" class="btn btn-secondary">Trở về</a>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/backend/categories/delete.blade.php ENDPATH**/ ?>