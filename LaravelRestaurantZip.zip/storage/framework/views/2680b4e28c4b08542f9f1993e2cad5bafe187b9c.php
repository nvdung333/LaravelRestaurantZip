
<?php $__env->startSection('title', "$title"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-md" id="product-container">
        <div class="row no-gutters">
            
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-4 col-6">
                <div class="card" id="product">
                    <div id="product-img">
                        <?php $product->Product_Img = str_replace("public/", "", $product->Product_Img); ?>
                        <img class="card-img-top" src="<?php echo e(asset("/storage/$product->Product_Img")); ?>" alt="product_img">
                    </div>
                    <div class="card-body" id="product-body">
                        <p id="product-name"><?php echo e($product->Product_Name); ?></p>
                        <span id="product-price"><?php echo e($product->Product_Price); ?> <u>đ</u></span>
                        <div style="font-size: small">
                            <?php if($product->Product_AvailableStatus == 0): ?>
                            <span style="color:white; background: #00c5cd">&nbspChưa mở bán&nbsp</span>
                            <?php endif; ?>
                            <?php if($product->Product_AvailableStatus == 1): ?>
                                <span style="color:white; background: #ffc125">&nbspSắp mở bán&nbsp</span>
                            <?php endif; ?>
                            <?php if($product->Product_AvailableStatus == 2): ?>
                                <span style="color:white; background: #008b00">&nbspĐang bán&nbsp</span>
                            <?php endif; ?>
                            <?php if($product->Product_AvailableStatus == 3): ?>
                                <span style="color:white; background: #8b2323">&nbspTạm ngưng bán&nbsp</span>
                            <?php endif; ?>
                            <?php if($product->Product_AvailableStatus == 4): ?>
                                <span style="color:white; background: #999999">&nbspĐã ngưng bán&nbsp</span>
                            <?php endif; ?>
                        </div>
                        <p id="product-description"><?php echo e($product->Product_Description); ?></p>
                        <a id="product-add-btn" href="#" class="btn btn-success <?php echo e($product->Product_AvailableStatus!=2 ? 'disabled' : ''); ?>">Mua ngay</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cart-btn'); ?>
    <?php echo $__env->make('frontend.partials.cart-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/category.blade.php ENDPATH**/ ?>