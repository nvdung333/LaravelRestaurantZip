<div id="cart-btn">
    <a class="btn" href="#cart">
        <div class="row">
            <div class="col-4">30 item(s)</div>
            <div class="col-4"><i class="fas fa-shopping-cart"></i><span id="cart-title"> Xem giỏ hàng</span></div>
            <div class="col-4">30000 VNĐ</div>
        </div>
    </a>
</div><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/cart-btn.blade.php ENDPATH**/ ?>