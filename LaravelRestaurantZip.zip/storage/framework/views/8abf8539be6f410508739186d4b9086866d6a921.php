
<?php $__env->startSection('title', "Payment"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-md" id="payment-container">

        <div id="payment-title">
            <p>Payment Information</p>
        </div>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(isset($items) && !empty($items)): ?>
            <form id="payment-form" method="POST" action="<?php echo e(url('payment/checkout')); ?>">
                <div class="row no-gutters">
                    <?php echo csrf_field(); ?>

                    <div class="col-md-7 col-sm-5" style="padding: 1px;">
                        <div id="payment-form-left">
                            <div class="form-group">
                                <label>Choose a store near you:</label>
                                    <select name="Restaurant_ID" id="" class="custom-select" required>
                                    <option selected disabled value="">Choose...</option>
                                    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($store->id); ?>"><?php echo e($store->Restaurant_Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <input type="hidden" name="User_ID" id="" value="<?php echo e(isset($auth['User_ID']) ? $auth['User_ID'] : ""); ?>">
                            <div class="form-group">
                                <label>Your name:</label>
                                <input type="text" name="Customer_Name"
                                    id="" class="form-control" placeholder="Type here..." required
                                    value="<?php echo e(old('Customer_Name', isset($auth['Customer_Name']) ? $auth['Customer_Name'] : "")); ?>">
                            </div>
                            <div class="form-group">
                                <label>Your phone number:</label>
                                <input type="text" name="Customer_Phone"
                                    id="" class="form-control" placeholder="Type here..." required
                                    value="<?php echo e(old('Customer_Phone', isset($auth['Customer_Phone']) ? $auth['Customer_Phone'] : "")); ?>">
                            </div>
                            <div class="form-group">
                                <label>Your address:</label>
                                <input type="text" name="Customer_Address"
                                    id="" class="form-control" placeholder="Type here..." required
                                    value="<?php echo e(old('Customer_Address', isset($auth['Customer_Address']) ? $auth['Customer_Address'] : "")); ?>">
                            </div>
                            <div class="form-group">
                                <label>Your email:</label>
                                <input type="email" name="Customer_Email"
                                    id="" class="form-control" placeholder="Type here..."
                                    value="<?php echo e(old('Customer_Email', isset($auth['Customer_Email']) ? $auth['Customer_Email'] : "")); ?>">
                            </div>
                            <div class="form-group">
                                <label>Note:</label>
                                <input type="text" name="Order_Note"
                                    id="" class="form-control" placeholder="Type here..."
                                    value="<?php echo e(old('Order_Note', "")); ?>">
                            </div>
                            <div id="payment-form-opt-return">
                                <a class="btn" href="<?php echo e(url('cart')); ?>">RETURN CART</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-5 col-sm-7" style="padding: 1px;">
                        <div id="payment-form-right">
                            <p id="payment-form-right-title">ĐƠN HÀNG</p>
                            <table id="payment-form-right-table" class="table table-borderless">

                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: left;"><?php echo e($item['itemName']); ?>&nbsp(x<?php echo e($item['itemQuantity']); ?>)</td>
                                        <td style="text-align: right;"><?php echo e($item['itemPrice'] * $item['itemQuantity']); ?>&nbsp<u>đ</u></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr id="payment-form-right-table-total">
                                    <th style="text-align: left; color: darkgreen;">THÀNH TIỀN</th>
                                    <th style="text-align: right; color: darkgreen;"><?php echo e($totalPrice); ?>&nbsp<u>đ</u></th>
                                </tr>

                            </table>
                            <div id="payment-form-right-submit">
                                <button type="submit"
                                    class="btn" <?php echo e(($items == null) ? 'disabled' : ''); ?>

                                    style="<?php echo e(($items == null) ? 'display:none' : ''); ?>"
                                    onclick='return confirm("Are you sure?")'>
                                    ORDER
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
            </form>
        <?php else: ?>
            <br>
            <p> <b>NO DATA FOUND!</b> </p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/payment/payment.blade.php ENDPATH**/ ?>