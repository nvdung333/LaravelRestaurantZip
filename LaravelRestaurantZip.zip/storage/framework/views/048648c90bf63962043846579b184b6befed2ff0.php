<div class="col-md-12" id="thenavbar">
    <nav class="navbar navbar-expand-md navbar-light">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto" id="navbar-ul">
                <li class="nav-item <?php echo e(Request::is('index') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(url("/index")); ?>">HOME</a></li>
                <?php $__currentLoopData = $nav_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item <?php echo e(Request::is("order/$nav_category->id") ? 'active' : ''); ?> <?php echo e(Request::is("order/$nav_category->id/*") ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(url("order/$nav_category->id/$nav_category->Category_Slug")); ?>"><?php echo e($nav_category->Category_Name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown">
                        INFORMATION
                    </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item <?php echo e(Request::segment(1) === "find-us" ? 'active' : ''); ?>" href="<?php echo e(url("/find-us")); ?>">FIND US</a>
                        <a class="dropdown-item <?php echo e(Request::segment(1) === "track" ? 'active' : ''); ?>" href="<?php echo e(url("/track")); ?>">ORDER TRACKING</a>
                    </div>
                </li>
            </ul>
            <form class="form-inline" method="get" action="<?php echo e(url("search")); ?>">
                <?php isset($search_keyword) ? $search_keyword : $search_keyword="" ?>
                <input name="keyword" class="form-control mr-sm-2" type="search" placeholder="Search..." aria-label="Search" value="<?php echo e($search_keyword); ?>">
                <button class="btn my-2 my-sm-0" type="submit"><i class="fas fa-search"></i></button>
            </form>
        </div>
    </nav>
</div><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/partials/navbar.blade.php ENDPATH**/ ?>