<div id="cart-btn">
    <a class="btn" href="<?php echo e(url('cart')); ?>">
        <div class="row">
            <div class="col-6">
                <i class="fas fa-shopping-cart"></i>
                <span id="cart-btn-title"> Xem giỏ hàng</span>
                <span id="cart-btn-totalQuantity"><?php echo e($totalQuantity); ?></span>
            </div>
            <div class="col-6"><span id="cart-btn-totalPrice"><?php echo e($totalPrice); ?></span> VNĐ</div>
        </div>
    </a>
</div><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/partials/cart-btn.blade.php ENDPATH**/ ?>