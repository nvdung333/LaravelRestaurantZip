
<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Danh sách các thể loại hàng hóa</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Report</a>
    </div>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <div style="padding-bottom: 10px">
        <a href="<?php echo e(url("/backend/category/create")); ?>" class="btn btn-primary">Tạo mới</a>
        <a href="<?php echo e(url("/backend/category/index")); ?>" class="btn btn-success">Refresh</a>
    </div>

    <form name="searchfilter" method="get" action="<?php echo e(htmlspecialchars($_SERVER["REQUEST_URI"])); ?>" style="border: 1px solid grey; border-radius: 5px; padding: 10px;">
        
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label for="keyword">Tìm kiếm</label>
                    <input type="text" name="keyword" id="keyword" class="form-control" placeholder="Search for..." value="<?php echo e($search_keyword); ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="whereSystemStatus">Trạng thái khóa...</label>
                    <select name="whereSystemStatus" id="whereSystemStatus" class="custom-select">
                        <option value="">Choose...</option>
                        <option value="1" <?php echo e($whereSystemStatus == "1" ? "selected" : ""); ?>>Mở khóa</option>
                        <option value="0" <?php echo e($whereSystemStatus == "0" ? "selected" : ""); ?>>Đang khóa</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="orderby">Sắp xếp theo...</label>
                    <select name="orderby" id="orderby" class="custom-select">
                        <option value="">Choose...</option>
                        <option value="id" <?php echo e($order_by == "id" ? "selected" : ""); ?>>ID</option>
                        <option value="Category_Name" <?php echo e($order_by == "Category_Name" ? "selected" : ""); ?>>Name</option>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="orderdir">Hướng sắp xếp...</label>
                    <select name="orderdir" id="orderdir" class="custom-select">
                        <option value="">Choose...</option>
                        <option value="ASC" <?php echo e($order_dir == "ASC" ? "selected" : ""); ?>>Ascending</option>
                        <option value="DESC" <?php echo e($order_dir == "DESC" ? "selected" : ""); ?>>Descending</option>
                    </select>
                </div>
            </div>
            <div class="col-md-1">
                <div class="form-group">
                    <label for="">Filter</label>
                    <div><button class="btn" style="background: #5a5c69; color: white;"><i class="fas fa-search"></i></button></div>
                </div>
            </div>
        </div>
    </form>

    <table class="table table-bordered table-striped table-sm">
        <thead class="thead-dark">
            <tr>
                <th>ID</th>
                <th></th>
                <th>Image</th>
                <th>Category_Name</th>
                <th>Slug</th>
                <th>Category_Parent</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            <?php if(isset($categories) && !empty($categories)): ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($category->id); ?></th>
                    <td style="text-align: center">
                        <?php if($category->Category_SystemStatus == 1): ?>
                            <span style="color:	#0000cd"><i class="fas fa-lock-open"></i></span>
                        <?php endif; ?>
                        <?php if($category->Category_SystemStatus == 0): ?>
                            <span style="color:	#cd0000"><i class="fas fa-lock"></i></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php $category->Category_Img = str_replace("public/", "", $category->Category_Img); ?>
                        <img alt=".img" src="<?php echo e(asset("storage/$category->Category_Img")); ?>" style="width: 52px; height: auto" />
                    </td>
                    <td><?php echo e($category->Category_Name); ?></td>
                    <td><?php echo e($category->Category_Slug); ?></td>
                    <td>
                        <?php $__currentLoopData = $parentcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pacategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($pacategory->t1_id == $category->id): ?>
                                <?php echo e($pacategory->t2_name); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                        <a href="<?php echo e(url("/backend/category/info/$category->id")); ?>" class="btn btn-info" data-toggle="tooltip" title="Info"><i class="fas fa-info-circle"></i></a>
                        <a href="<?php echo e(url("/backend/category/edit/$category->id")); ?>" class="btn btn-warning" data-toggle="tooltip" title="Edit"><i class="fas fa-edit"></i></a>
                        <a href="<?php echo e(url("/backend/category/delete/$category->id")); ?>" class="btn btn-danger" data-toggle="tooltip" title="Delete"><i class="fas fa-minus-circle"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                Chưa có bản ghi nào trong bảng này
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($categories->links("pagination::bootstrap-4")); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('appendjs'); ?>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/backend/categories/index.blade.php ENDPATH**/ ?>