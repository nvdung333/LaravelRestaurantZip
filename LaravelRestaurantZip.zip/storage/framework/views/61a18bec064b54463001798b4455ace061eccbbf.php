
<?php $__env->startSection('title', 'Find Us'); ?>

<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/restaurant.blade.php ENDPATH**/ ?>