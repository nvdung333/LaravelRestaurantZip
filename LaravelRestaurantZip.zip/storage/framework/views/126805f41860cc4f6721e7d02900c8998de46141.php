
<?php $__env->startSection('title', 'Orders'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Thông tin chi tiết đơn đặt hàng</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Report</a>
    </div>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div style="padding-bottom: 10px">
        <a href="<?php echo e(url("/backend/order/index")); ?>" class="btn btn-secondary">Trở về</a>
        <a href="<?php echo e(url("/backend/order/info/$order->id")); ?>" class="btn btn-success">Refresh</a>
    </div>

    <form method="post" action="<?php echo e(url("/backend/order/info/$order->id")); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <span style="background: black; padding: 3px">
                <label style="color:white">ID:</label>
                <a style="color:lightgreen"><?php echo e($order->id); ?></a>
            </span>
        </div>

        <div style="border: 1px solid grey; border-radius: 5px; padding: 11px;">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Tracking Code:</label>
                        <span type="text" style="font-weight: bold;"><?php echo e($order->Order_TrackingCode); ?></span>
                        <br>
                        <label>Status:</label>
                        <?php if($order->Order_Status == 0): ?> <span style="background: white; color: black; padding: 0 5px;"><i class="fas fa-window-close"></i> <?php echo e($status[0]); ?></span> <?php endif; ?>
                        <?php if($order->Order_Status == 1): ?> <span style="background: #00cd66; color: white; padding: 0 5px;"><?php echo e($status[1]); ?></span> <?php endif; ?>
                        <?php if($order->Order_Status == 2): ?> <span style="background: #4876ff; color: white; padding: 0 5px;"><?php echo e($status[2]); ?></span> <?php endif; ?>
                        <?php if($order->Order_Status == 3): ?> <span style="background: #ffc125; color: white; padding: 0 5px;"><?php echo e($status[3]); ?></span> <?php endif; ?>
                        <?php if($order->Order_Status == 4): ?> <span style="background: #cd5b45; color: white; padding: 0 5px;"><?php echo e($status[4]); ?></span> <?php endif; ?>
                        <?php if($order->Order_Status == 5): ?> <span style="background: black; color: white; padding: 0 5px;"><?php echo e($status[5]); ?></span> <?php endif; ?>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Customer Name:</label>
                        <input type="text" class="form-control" value="<?php echo e($order->Customer_Name); ?>" readonly>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Customer Phone:</label>
                        <input type="text" class="form-control" value="<?php echo e($order->Customer_Phone); ?>" readonly>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Customer Email:</label>
                        <input type="text" class="form-control" value="<?php echo e($order->Customer_Email); ?>" readonly>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label>Customer Address:</label>
                        <input type="text" name="Customer_Address" class="form-control" value="<?php echo e($order->Customer_Address); ?>" >
                    </div>
                </div>
    
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Restaurant:</label>
                        <input type="text" class="form-control" value="<?php echo e($order->Order_RestaurantName); ?>" readonly>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Restaurant: (for editing)</label>
                        <select class="custom-select" name="Restaurant_ID">
                            <option value="">Choose...</option>
                            <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($restaurant->id); ?>"
                                    <?php if($order->Restaurant_ID == $restaurant->id): ?> selected <?php endif; ?>>
                                    <?php echo e($restaurant->Restaurant_Name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Restaurant Staff:</label>
                        <input type="text" name="Restaurant_Staff" class="form-control" value="<?php echo e($order->Restaurant_Staff); ?>">
                    </div>
                </div>
            </div>

            <button type="submit" onclick='return confirm("Are you sure?")' class="btn btn-dark">Update</button>
        </div>
    </form>

    <div class="div" style="border: 1px solid grey; border-radius: 5px; padding: 11px; margin-bottom: 12px;">
        <div class="row">
            <div class="col-md-6">
                <div class="table-responsive-md">
                    <table class="table table-bordered">
                        <tr>
                            <th>Time Request</th>
                            <td><?php echo e($order->Order_Time_Request); ?></td>
                        </tr>
                        <tr>
                            <th>Time Accept</th>
                            <td><?php echo e($order->Order_Time_Accept); ?></td>
                        </tr>
                        <tr>
                            <th>Time Complete</th>
                            <td><?php echo e($order->Order_Time_Complete); ?></td>
                        </tr>
                        <tr>
                            <th>Time Receive</th>
                            <td><?php echo e($order->Order_Time_Receive); ?></td>
                        </tr>
                        <tr>
                            <th>Time Cancel</th>
                            <td><?php echo e($order->Order_Time_Cancel); ?></td>
                        </tr>
                        <tr>
                            <th>Time Return</th>
                            <td><?php echo e($order->Order_Time_Return); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="col-md-6">
                <div class="table-responsive-md">
                    <table class="table table-bordered">
                        <tr>
                            <th>Created At</th>
                            <td><?php echo e($order->created_at); ?></td>
                        </tr>
                        <tr>
                            <th>Updated At</th>
                            <td><?php echo e($order->updated_at); ?></td>
                        </tr>
                        <tr>
                            <th>Created User</th>
                            <td> <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($user->id == $order->created_user): ?> <?php echo e($user->User_FullName); ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </td>
                        </tr>
                        <tr>
                            <th>Modified User</th>
                            <td> <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($user->id == $order->modified_user): ?> <?php echo e($user->User_FullName); ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="table-responsive-md">
        <table class="table table-bordered table-sm">
            <thead class="thead-dark">
                <th colspan="2">Order Details</th>
            </thead>
            <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <label style="font-size: large">
                            <i class="far fa-sticky-note"></i>
                            Product: <b><?php echo e($orderdetail->OrderDetail_ProductName); ?> (x<?php echo e($orderdetail->OrderDetail_Quantity); ?>)</b>
                        </label><br>
                        <label>- Price: <b><?php echo e($orderdetail->OrderDetail_ProductPrice); ?></b></label><br>
                        <label>- Total Price: <b><?php echo e($orderdetail->OrderDetail_TotalPrice); ?></b></label><br>
                        <label>- Detail Note: <b><?php echo e($orderdetail->OrderDetail_Note); ?></b></label><br>
                    </td>
                    <td>
                        <label>- Order detail id: <b><?php echo e($orderdetail->id); ?></b></label><br>
                        <label>- Created at: <b><?php echo e($orderdetail->created_at); ?></b></label><br>
                        <label>- Updated at: <b><?php echo e($orderdetail->updated_at); ?></b></label><br>
                        <label>- Created user id: <b><?php echo e($orderdetail->created_user); ?></b></label><br>
                        <label>- Modified user id: <b><?php echo e($orderdetail->modified_user); ?></b></label>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    <div style="border: 1px solid grey; border-radius: 5px; padding: 11px; margin-bottom: 12px;">
        <div class="row" style="text-align: center;">
            <div class="col-md-12" style="text-align: start">
                <div class="form-group">
                    <label for="Order_Note">Note:</label>
                    <textarea class="form-control" rows="3" readonly><?php echo e($order->Order_Note); ?></textarea>
                </div>
            </div>
            <div class="col-md-3">
                <form method="post" action="<?php echo e(url("/backend/order/status/$order->id")); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="Order_Status" value="1">
                    <button type="submit" onclick='return confirm("Are you sure?")' class="btn btn-success">SET REQUEST</button>
                </form>
            </div>
            <div class="col-md-3">
                <form method="post" action="<?php echo e(url("/backend/order/status/$order->id")); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="Order_Status" value="2">
                    <button type="submit" onclick='return confirm("Are you sure?")' class="btn btn-primary">SET ACCEPT</button>
                </form>
            </div>
            <div class="col-md-3">
                <form method="post" action="<?php echo e(url("/backend/order/status/$order->id")); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="Order_Status" value="3">
                    <button type="submit" onclick='return confirm("Are you sure?")' class="btn btn-warning">SET COMPLETE</button>
                </form>
            </div>
            <div class="col-md-3">
                <form method="post" action="<?php echo e(url("/backend/order/status/$order->id")); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="Order_Status" value="4">
                    <button type="submit" onclick='return confirm("Are you sure?")' class="btn btn-danger">SET RECEIVE</button>
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <form method="post" action="<?php echo e(url("/backend/order/status/$order->id")); ?>" enctype="multipart/form-data" style="border: 1px solid grey; border-radius: 5px; padding: 11px;">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Cancel by: <?php echo e($order->Order_CancelBy); ?></label><br>
                    <label>Cancel reason:</label>
                    <input type="hidden" name="Order_Status" value="0">
                    <input type="text" name="Order_CancelReason" class="form-control" value="<?php echo e($order->Order_CancelReason); ?>">
                </div>
                <button type="submit" onclick='return confirm("Are you sure?")' class="btn btn-dark">SET CANCEL ORDER</button>
            </form>
        </div>
        <div class="col-md-12">
            <form method="post" action="<?php echo e(url("/backend/order/status/$order->id")); ?>" enctype="multipart/form-data" style="border: 1px solid grey; border-radius: 5px; padding: 11px;">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Return reason:</label>
                    <input type="hidden" name="Order_Status" value="5">
                    <input type="text" name="Order_ReturnReason" class="form-control" value="<?php echo e($order->Order_ReturnReason); ?>">
                </div>
                <button type="submit" onclick='return confirm("Are you sure?")' class="btn btn-dark">SET RETURN GOODS</button>
            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/backend/orders/info.blade.php ENDPATH**/ ?>