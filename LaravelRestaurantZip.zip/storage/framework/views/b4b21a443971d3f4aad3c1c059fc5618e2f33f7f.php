<div class="col-md-12" class="header" id="header">
    <div id="header-left">
        <a href="<?php echo e(url("/")); ?>">
            <img id="header-logo-0" src="<?php echo e(asset("/storage/images_setting/logo-0.png")); ?>" alt="logo">
            <img id="header-logo-1" src="<?php echo e(asset("/storage/images_setting/logo-dark.png")); ?>" alt="logo">
        </a>
    </div>      
    <div id="header-right">
        <?php if(auth()->guard()->guest()): ?>
            <?php if(Route::has('login')): ?>
                <a href="<?php echo e(route("login")); ?>" style="color: brown; font-weight: bold"><?php echo e(__("Login")); ?></a>
            <?php endif; ?>
        
            <?php if(Route::has('register')): ?>
                <a href="<?php echo e(route('register')); ?>" style="color: brown"><?php echo e(__('Register')); ?></a>
            <?php endif; ?>
        <?php else: ?>
            <div class="btn-group">
                <button type="button" class="btn dropdown-toggle btn-sm" data-toggle="dropdown" data-display="static" aria-haspopup="true" aria-expanded="false" style="background: chocolate; color: #fafad2; font-weight: bolder;">
                    <?php echo e(Auth::user()->User_FullName); ?>

                </button>
                <div class="dropdown-menu dropdown-menu-right" style="background: #ffffe0;">
                    <a class="dropdown-item" href="<?php echo e(url('user/history')); ?>" style="color: brown;"><i class="fas fa-history"></i> History</a>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            style="color: brown;"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                        <i class="fas fa-sign-out-alt"></i> <?php echo e(__('Logout')); ?>

                    </a>
                </div>
            </div>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        <?php endif; ?>
    </div>
</div><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/partials/header.blade.php ENDPATH**/ ?>