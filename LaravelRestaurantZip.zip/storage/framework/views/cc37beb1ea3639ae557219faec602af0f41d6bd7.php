<footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Vinakook &copy; 2021</span>
                    </div>
                </div>
            </footer><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/backend/partials/footer.blade.php ENDPATH**/ ?>