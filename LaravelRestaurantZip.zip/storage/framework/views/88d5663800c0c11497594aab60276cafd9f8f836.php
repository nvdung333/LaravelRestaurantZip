
<?php $__env->startSection('title', 'Find Us'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row no-gutters" style="padding: 15px 0px">

            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4" style="padding: 1px 2px">
                    <div style="border: 1px solid black; padding: 5px">
                        <p style="background: #eeeed1; padding: 0px 7px; font-weight:bold; font-size: 30px; text-align: center"><?php echo e($area); ?></p>
                        <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($area == $restaurant->Restaurant_Area): ?>
                                <label style="font-weight: bold; font-size:large "><i class="fas fa-map-marker-alt"></i> <?php echo e($restaurant->Restaurant_Name); ?></label><br>
                                <label>- Address: <?php echo e($restaurant->Restaurant_Address); ?></label><br>
                                <label>- Phone Number: <?php echo e($restaurant->Restaurant_Phone); ?></label><br>
                                <label>- Status: 
                                    <?php if($restaurant->Restaurant_OpenStatus == 0): ?> <span style="color: #00008b; ">Sắp khai trương</span> <?php endif; ?>
                                    <?php if($restaurant->Restaurant_OpenStatus == 1): ?> <span style="color: #006400; ">Đang hoạt động</span> <?php endif; ?>
                                    <?php if($restaurant->Restaurant_OpenStatus == 2): ?> <span style="color: #cd6600; ">Tạm ngưng hoạt động</span> <?php endif; ?>
                                    <?php if($restaurant->Restaurant_OpenStatus == 3): ?> <span style="color: #cd0000; ">Đã đóng vĩnh viễn</span> <?php endif; ?>
                                </label><br>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('cart-btn'); ?>
    <?php echo $__env->make('frontend.partials.cart-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/find-us.blade.php ENDPATH**/ ?>