
<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Thông tin chi tiết sản phẩm</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Report</a>
    </div>
    
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <form enctype="multipart/form-data">

        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Category_ID">Category:</label>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($category->id == $product->Category_ID): ?>
                        <input type="text" name="Category_ID" id="Category_ID" class="form-control" value="<?php echo e($category->Category_Name); ?>" readonly>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Product_Name">Name:</label>
                    <input type="text" name="Product_Name" id="Product_Name" class="form-control" value="<?php echo e($product->Product_Name); ?>" readonly>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Product_Price">Price:</label>
                    <input type="text" name="Product_Price" id="Product_Price" class="form-control" value="<?php echo e($product->Product_Price); ?>" readonly>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Product_AvailableStatus">Available Status:&nbsp</label>
                    <?php if($product->Product_AvailableStatus == 0): ?> <span style="color:white; background: #00c5cd">&nbspChưa mở bán&nbsp</span> <?php endif; ?>
                    <?php if($product->Product_AvailableStatus == 1): ?> <span style="color:white; background: #ffc125">&nbspSắp mở bán&nbsp</span> <?php endif; ?>
                    <?php if($product->Product_AvailableStatus == 2): ?> <span style="color:white; background: #008b00">&nbspĐang bán&nbsp</span> <?php endif; ?>
                    <?php if($product->Product_AvailableStatus == 3): ?> <span style="color:white; background: #8b2323">&nbspTạm ngưng bán&nbsp</span> <?php endif; ?>
                    <?php if($product->Product_AvailableStatus == 4): ?> <span style="color:white; background: #999999">&nbspĐã ngưng bán&nbsp</span> <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Product_SystemStatus">System Status:&nbsp</label>
                    <?php if($product->Product_SystemStatus == 1): ?> <span style="color:	#0000cd"><i class="fas fa-lock-open"></i> Mở khóa</span> <?php endif; ?>
                    <?php if($product->Product_SystemStatus == 0): ?> <span style="color:	#cd0000"><i class="fas fa-lock"></i> Đang khóa</span> <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="Product_Img">Image:</label>
            <br>
            <?php $product->Product_Img = str_replace("public/", "", $product->Product_Img); ?>
            <img alt=".img" src="<?php echo e(asset("storage/$product->Product_Img")); ?>" style="width: 200px; height: auto" />
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Product_Description">Description:</label>
                    <textarea name="Product_Description" class="form-control" rows="5" id="Product_Description" readonly><?php echo e($product->Product_Description); ?></textarea>
                </div>
            </div>
        </div>


        <a href="<?php echo e(url("/backend/product/edit/$product->id")); ?>" class="btn btn-warning">Edit</a>
        <a href="<?php echo e(url("/backend/product/delete/$product->id")); ?>" class="btn btn-danger">Delete</a>
        <a href="<?php echo e(url("/backend/product/index")); ?>" class="btn btn-secondary">Trở về</a>
        <a href="<?php echo e(url("/backend/product/details/$product->id")); ?>" class="btn btn-success">Refresh</a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/backend/products/details.blade.php ENDPATH**/ ?>