
<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Thông tin chi tiết danh mục hàng hóa</h1>
        <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                class="fas fa-download fa-sm text-white-50"></i> Report</a>
    </div>
    
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <form enctype="multipart/form-data">

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Category_Name">Name:</label>
                    <input type="text" name="Category_Name" id="Category_Name" class="form-control" value="<?php echo e($category->Category_Name); ?>" readonly>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="slug">Slug:</label>
                    <input type="text" name="slug" id="slug" class="form-control" value="<?php echo e($category->slug); ?>" readonly>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="Category_Img">Image:</label>
            <br>
            <?php $category->Category_Img = str_replace("public/", "", $category->Category_Img); ?>
            <img alt=".img" src="<?php echo e(asset("storage/$category->Category_Img")); ?>" style="width: 200px; height: auto" />
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Category_Description">Description:</label>
                    <textarea name="Category_Description" class="form-control" rows="5" id="Category_Description" readonly><?php echo e($category->Category_Description); ?></textarea>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="Category_Parent_ID">Parent Category:</label>
                    <?php $__currentLoopData = $parentcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($parentcategory->id == $category->Category_Parent_ID): ?>
                        <input type="text" name="Category_Parent_ID" id="Category_Parent_ID" class="form-control" value="<?php echo e($parentcategory->Category_Name); ?>" readonly>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->Category_Parent_ID == ""): ?>
                        <input type="text" name="Category_Parent_ID" id="Category_Parent_ID" class="form-control" value="" readonly>
                    <?php endif; ?>
                </div>
            </div>
        </div>


        <a href="<?php echo e(url("/backend/category/edit/$category->id")); ?>" class="btn btn-warning">Edit</a>
        <a href="<?php echo e(url("/backend/category/delete/$category->id")); ?>" class="btn btn-danger">Delete</a>
        <a href="<?php echo e(url("/backend/category/index")); ?>" class="btn btn-secondary">Trở về</a>
        <a href="<?php echo e(url("/backend/category/details/$category->id")); ?>" class="btn btn-success">Refresh</a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/backend/categories/details.blade.php ENDPATH**/ ?>