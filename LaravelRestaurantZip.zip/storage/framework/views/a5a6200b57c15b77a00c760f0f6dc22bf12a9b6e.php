
<?php $__env->startSection('title', "Cart"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-md" id="cart-site-container">

        <div id="cart-site-title">
            <p>Shopping Cart</p>
        </div>

        <div class="table-responsive">
            <table id="cart-site-table" class="table table-bordered">
                <tbody id="cart-site-tbody">
                    <?php if(isset($items) && !empty($items)): ?>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php $itemImage = str_replace("public/", "", $item['itemImage']); ?>
                                    <img id="cart-site-tbody-img" src="<?php echo e(asset("/storage/$itemImage")); ?>" alt="">
                                </td>
                                <td>
                                    <p id="cart-site-tbody-name"><?php echo e($item['itemName']); ?></p>
                                    <p id="cart-site-tbody-price"><span><?php echo e($item['itemPrice']); ?>&nbspVNĐ</span></p>
                                    <p id="cart-site-tbody-qtt-label">Quantity:</p>
                                    <select class="custom-select custom-select-sm"
                                        style="background-color: #fff8dc; font-weight: bold; width:max-content"
                                        id="QttSelOpt" data-sessionID="<?php echo e($item['sessionID']); ?>">
                                        <?php for($i = 1; $i <= 100; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php echo e($i==$item['itemQuantity'] ? "selected" : ""); ?>><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <p id="cart-site-tbody-total">Total: <span><?php echo e((float)$item['itemPrice'] * (int)$item['itemQuantity']); ?>&nbspVNĐ</span></p>
                                    <p id="cart-site-tbody-note">Note: <span><?php echo e($item['itemNote']); ?></span></p>
                                </td>
                                <!-- REMOVE ITEM FROM CART -->
                                <td style="text-align: center; vertical-align: middle;">
                                    <button
                                        class="btn btn-warning RemoveItem"
                                        style="color: white"
                                        data-sessionID="<?php echo e($item['sessionID']); ?>">
                                        X
                                    </button>
                                </td>
                                <!-- end -->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <br>
                        <p> <b>NO DATA FOUND!</b> </p>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div id="cart-site-opt">
            <a id="cart-site-opt-continue" class="btn" href="<?php echo e(url('search')); ?>">CONTINUE SHOPPING</a>
            <!-- CLEAR CART -->
            <a class="btn btn-danger" href="<?php echo e(url('/cart/clear/')); ?>">CLEAR ALL</a>
            <!-- end -->
        </div>

        <div class="container">
            <div class="row">
                <div id="cart-site-box" class="col-md-6">
                    <h3 id="cart-site-box-title">Cart total</h3>
                    <div id="cart-site-box-row" class="row">
                        <div class="col-6">
                            <p id="cart-site-box-left">Total item(s)</p>
                        </div>
                        <div class="col-6">
                            <p id="cart-site-box-right"><?php echo e($totalItem); ?></p>
                        </div>
                    </div>
                    <div id="cart-site-box-row" class="row">
                        <div class="col-6">
                            <p id="cart-site-box-left">Total quantity</p>
                        </div>
                        <div class="col-6">
                            <p id="cart-site-box-right"><?php echo e($totalQuantity); ?></p>
                        </div>
                    </div>
                    <div id="cart-site-box-row" class="row">
                        <div class="col-6">
                            <p id="cart-site-box-left">Total price</p>
                        </div>
                        <div class="col-6">
                            <p id="cart-site-box-right"><?php echo e($totalPrice); ?><span>&nbsp<u>đ</u></span></p>
                        </div>
                    </div>
                    <div id="cart-site-box-proceed">
                        <a class="btn <?php echo e(($items == null) ? 'disabled' : ''); ?>"
                            style="<?php echo e(($items == null) ? 'display:none' : ''); ?>"
                            href="<?php echo e(url('payment')); ?>">
                            PROCEED TO CHECKOUT
                        </a>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('appendjs'); ?>
    <script>
        $(document).ready(function () {

            // UPDATE ITEM QUANTITY
            $("body").on("change", "#QttSelOpt", function(e) {
                var ssID = $(this).attr("data-sessionID");
                var newQtt = $(this).val();
                var token = "<?php echo e(csrf_token()); ?>";
                var type = "PUT";
                var formData = {
                    ssID: ssID,
                    newQtt: newQtt,
                    _token: token,
                }
                var ajaxurl = "<?php echo e(url('/cart/update/')); ?>"+"/"+ssID;
                $.ajax({
                    type: type,
                    url: ajaxurl,
                    data: formData,
                    dataType: "json",
                    success: function(data) {
                        console.log(data);
                        location.reload();
                    }
                });
            });
            
            // REMOVE ITEM
            $("body").on("click", ".RemoveItem", function(e) {
                var ssID = $(this).attr("data-sessionID");
                var token = "<?php echo e(csrf_token()); ?>";
                var type = "PUT";
                var formData = {
                    ssID: ssID,
                    _token: token,
                }
                var ajaxurl = "<?php echo e(url('/cart/remove/')); ?>"+"/"+ssID;
                $.ajax({
                    type: type,
                    url: ajaxurl,
                    data: formData,
                    dataType: "json",
                    success: function(data) {
                        console.log(data);
                        location.reload();
                    }
                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/cart.blade.php ENDPATH**/ ?>