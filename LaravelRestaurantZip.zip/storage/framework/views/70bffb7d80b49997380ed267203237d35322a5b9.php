
<?php $__env->startSection('title', "History"); ?>

<?php $__env->startSection('content'); ?>

    <style>
        #track-container input:read-only, #track-container textarea:read-only
        {background-color:lemonchiffon; color:saddlebrown}
    </style>

    <div class="container-md" id="track-container">

        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        
            <?php if(isset($order) && !empty($order)): ?>
                <div style="padding-bottom: 10px">
                    <a href="<?php echo e(url("/user/history/")); ?>" class="btn btn-secondary">Trở về</a>
                    <a href="<?php echo e(url("/user/history/$order->id")); ?>" class="btn btn-success">Refresh</a>
                </div>

                <div style="border: 1px solid saddlebrown; border-radius: 5px; padding: 11px; margin-bottom: 12px;">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Tracking Code:</label>
                                <span type="text" style="font-weight: bold;"><?php echo e($order->Order_TrackingCode); ?></span>
                                <br>
                                <label>Status:</label>
                                <?php if($order->Order_Status == 0): ?> <span style="background:#f5f5f5; color:black; padding:2px 5px;"><i class="fas fa-window-close"></i> <?php echo e($status[0]); ?></span> <?php endif; ?>
                                <?php if($order->Order_Status == 1): ?> <span style="background:#008b00; color:white; padding:2px 5px;"><?php echo e($status[1]); ?></span> <?php endif; ?>
                                <?php if($order->Order_Status == 2): ?> <span style="background:#00008b; color:white; padding:2px 5px;"><?php echo e($status[2]); ?></span> <?php endif; ?>
                                <?php if($order->Order_Status == 3): ?> <span style="background:#8b8b00; color:white; padding:2px 5px;"><?php echo e($status[3]); ?></span> <?php endif; ?>
                                <?php if($order->Order_Status == 4): ?> <span style="background:#8b0000; color:white; padding:2px 5px;"><?php echo e($status[4]); ?></span> <?php endif; ?>
                                <?php if($order->Order_Status == 5): ?> <span style="background:black; color:white; padding:2px 5px;"><?php echo e($status[5]); ?></span> <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Customer Name:</label>
                                <input id="abc" type="text" class="form-control" value="<?php echo e($order->Customer_Name); ?>" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Customer Phone:</label>
                                <input type="text" class="form-control" value="<?php echo e($order->Customer_Phone); ?>" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Customer Email:</label>
                                <input type="text" class="form-control" value="<?php echo e($order->Customer_Email); ?>" readonly>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Customer Address:</label>
                                <input type="text" class="form-control" value="<?php echo e($order->Customer_Address); ?>" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Restaurant:</label>
                                <input type="text" class="form-control" value="<?php echo e($order->Order_RestaurantName); ?>" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Restaurant Staff:</label>
                                <input type="text" class="form-control" value="<?php echo e($order->Restaurant_Staff); ?>" readonly>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="div" style="border: 1px solid saddlebrown; border-radius: 5px; padding: 11px; margin-bottom: 12px;">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive-md">
                                <table class="table table-bordered">
                                    <tr>
                                        <td>Time Request</td>
                                        <th><?php echo e($order->Order_Time_Request); ?></th>
                                    </tr>
                                    <tr>
                                        <td>Time Accept</td>
                                        <th><?php echo e($order->Order_Time_Accept); ?></th>
                                    </tr>
                                    <tr>
                                        <td>Time Complete</td>
                                        <th><?php echo e($order->Order_Time_Complete); ?></th>
                                    </tr>
                                    <tr>
                                        <td>Time Receive</td>
                                        <th><?php echo e($order->Order_Time_Receive); ?></th>
                                    </tr>
                                    <tr>
                                        <td>Time Cancel</td>
                                        <th><?php echo e($order->Order_Time_Cancel); ?></th>
                                    </tr>
                                    <tr>
                                        <td>Cancel By</td>
                                        <th><?php echo e($order->Order_CancelBy); ?></th>
                                    </tr>
                                    <tr>
                                        <td>Cancel Reason</td>
                                        <th><?php echo e($order->Order_CancelReason); ?></th>
                                    </tr>
                                    <tr>
                                        <td>Time Return</td>
                                        <th><?php echo e($order->Order_Time_Return); ?></th>
                                    </tr>
                                    <tr>
                                        <td>Return Reason</td>
                                        <th><?php echo e($order->Order_ReturnReason); ?></th>
                                    </tr>
                                    <tr>
                                        <td>Created At</td>
                                        <th><?php echo e($order->created_at); ?></th>
                                    </tr>
                                    <tr>
                                        <td>Updated At</td>
                                        <th><?php echo e($order->updated_at); ?></th>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <br>
                <p> <b>NO DATA FOUND!</b> </p>
            <?php endif; ?>
        

        
            <?php if(isset($orderdetails) && !empty($orderdetails->toarray())): ?>
                <div class="table-responsive-md">
                    <table class="table table-bordered table-sm">
                        <thead class="thead-dark">
                            <th colspan="1" style="font-size:large;">Order Details</th>
                        </thead>
                        <?php $__currentLoopData = $orderdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <label style="font-size:large;">
                                        <i class="far fa-sticky-note"></i>
                                        Product: <b><?php echo e($orderdetail->OrderDetail_ProductName); ?> (x<?php echo e($orderdetail->OrderDetail_Quantity); ?>)</b>
                                    </label><br>
                                    <label>- Price: <b><?php echo e($orderdetail->OrderDetail_ProductPrice); ?></b></label><br>
                                    <label>- Total Price: <b><?php echo e($orderdetail->OrderDetail_TotalPrice); ?></b></label><br>
                                    <label>- Detail Note: <b><?php echo e($orderdetail->OrderDetail_Note); ?></b></label><br>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <div class="form-group">
                    <label for="Order_Note">Note:</label>
                    <textarea class="form-control" rows="3" readonly><?php echo e($order->Order_Note); ?></textarea>
                </div>
            <?php else: ?>
                <br>
                <p> <b>NO DATA FOUND!</b> </p>
            <?php endif; ?>
        

        
            <?php if(isset($order) && !empty($order)): ?>
                <div class="row">
                    <?php if($order->Order_Status == 1): ?>
                        <div class="col-md-12">
                            <form method="post" action="<?php echo e(url("/user/history/$order->id")); ?>"
                                enctype="multipart/form-data"
                                style="border: 1px solid grey; border-radius: 5px; padding: 11px; margin-bottom: 12px">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Cancel reason:</label>
                                    <input type="hidden" name="Order_Status" value="0">
                                    <input type="text" name="Order_CancelReason" class="form-control" value="<?php echo e($order->Order_CancelReason); ?>">
                                </div>
                                <button type="submit" onclick='return confirm("Are you sure?")' class="btn btn-dark">SET CANCEL ORDER</button>
                            </form>
                        </div>
                    <?php endif; ?>
                    <?php if($order->Order_Status == 4): ?>
                        <div class="col-md-12">
                            <form method="post" action="<?php echo e(url("/user/history/$order->id")); ?>"
                                enctype="multipart/form-data"
                                style="border: 1px solid grey; border-radius: 5px; padding: 11px; margin-bottom: 12px">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>Return reason:</label>
                                    <input type="hidden" name="Order_Status" value="5">
                                    <input type="text" name="Order_ReturnReason" class="form-control" value="<?php echo e($order->Order_ReturnReason); ?>">
                                </div>
                                <button type="submit" onclick='return confirm("Are you sure?")' class="btn btn-dark">SET RETURN GOODS</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <br>
                <p> <b>NO DATA FOUND!</b> </p>
            <?php endif; ?>
        

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/user/historyInfo.blade.php ENDPATH**/ ?>