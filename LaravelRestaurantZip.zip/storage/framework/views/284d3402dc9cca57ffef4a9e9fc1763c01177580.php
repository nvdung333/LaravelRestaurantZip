<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VINAKOOK - <?php echo $__env->yieldContent("title"); ?></title>

    <!-- fontawesome -->
    <link rel="stylesheet" href="<?php echo e(asset("/fe-assets/site/vendor/fontawesome-free-5.15.3-web/css/all.css")); ?>">

    <!-- bootstrap css -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("/fe-assets/site/vendor/bootstrap-4.6.0/css/bootstrap.css")); ?>">
    
    <!-- bootstrap jquery -->
    <script src="<?php echo e(asset("/fe-assets/site/vendor/jquery/jquery-3.6.0.slim.min.js")); ?>"></script>
    <script src="<?php echo e(asset("/fe-assets/site/vendor/jquery/jquery-3.6.0.min.js")); ?>"></script>

    <!-- bootstrap javascript 1 -->
    <script src="<?php echo e(asset("/fe-assets/site/vendor/bootstrap-4.6.0/js/bootstrap.bundle.min.js")); ?>"></script>

    <!-- bootstrap popper -->
    <script src="<?php echo e(asset("/fe-assets/site/vendor/popper.min.js")); ?>"></script>

    <!-- bootstrap javascript 2 -->
    <script src="<?php echo e(asset("/fe-assets/site/vendor/bootstrap-4.6.0/js/bootstrap.min.js")); ?>"></script>

    
    <!-- Custom styles for this template-->
    <link rel="stylesheet" href="<?php echo e(asset("/fe-assets/site/site-css.css")); ?>">
</head>
<body>
    <!-- section-header&navbar -->
    <section class="row no-gutters" id="ontopsticky">
        <?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('frontend.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <!-- end section-header&navbar -->


    <!-- section-content -->
    <section class="content" id="content">
        <?php echo $__env->yieldContent('content'); ?>
    </section>
    <!-- end section-content -->


    <!-- section-footer -->
    <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end section-footer -->


    <!-- cart button -->
    <?php echo $__env->yieldContent('cart-btn'); ?>
    <!-- end cart button -->

    <!-- Custom JS for this template-->
    <script src="<?php echo e(asset("/fe-assets/site/site-js.js")); ?>"></script>

    <?php echo $__env->yieldContent('appendjs'); ?>

</body>
</html>


<?php /**PATH D:\xampp\htdocs\T3H\1-ProjectForTheEndOfTheCourse\LaravelRestaurant\resources\views/frontend/layouts/main.blade.php ENDPATH**/ ?>